from __future__ import annotations

import argparse
import json
from pathlib import Path
from typing import Dict, List, Tuple


BASE_DIR = Path(__file__).resolve().parents[2]
ROLE_PROFILE_PATH = BASE_DIR / "data" / "role_profiles" / "role_profiles.json"
DEFAULT_OUTPUT_PATH = BASE_DIR / "data" / "processed" / "gap_analysis_result.json"


ROLE_ALIASES = {
    "sql": "SQL",
    "excel": "Excel",
    "power bi": "Power BI",
    "powerbi": "Power BI",
    "tableau": "Tableau",
    "python": "Python",
    "pandas": "Pandas",
    "numpy": "NumPy",
    "statistics": "Statistics",
    "machine learning": "Machine Learning",
    "deep learning": "Deep Learning",
    "pytorch": "PyTorch",
    "tensorflow": "TensorFlow",
    "scikit-learn": "Scikit-learn",
    "sklearn": "Scikit-learn",
    "spark": "Spark",
    "airflow": "Airflow",
    "etl": "ETL",
    "data warehouse": "Data Warehouse",
    "nlp": "NLP",
    "computer vision": "Computer Vision",
    "dashboard": "Dashboarding",
    "data visualization": "Data Visualization",
    "git": "Git",
    "docker": "Docker",
    "linux": "Linux",
    "mysql": "MySQL",
    "postgresql": "PostgreSQL",
    "postgres": "PostgreSQL",
    "mongodb": "MongoDB",
    "aws": "AWS",
    "azure": "Azure",
    "gcp": "GCP",
    "llm": "LLM",
    "rag": "RAG",
    "langchain": "LangChain",
    "streamlit": "Streamlit",
    "flask": "Flask",
    "fastapi": "FastAPI",
}


ROLE_KEYWORD_HINTS = {
    "Data Analyst": ["sql", "excel", "power bi", "tableau", "statistics", "dashboard"],
    "Data Engineer": ["python", "sql", "etl", "airflow", "spark", "data warehouse"],
    "AI Engineer": ["python", "machine learning", "deep learning", "pytorch", "tensorflow", "llm"],
    "AI Researcher": ["machine learning", "deep learning", "research", "experiment", "paper", "statistics"],
    "Data Scientist": ["python", "machine learning", "statistics", "pandas", "numpy", "modeling"],
    "Data Labeling": ["annotation", "data labeling", "quality control", "review"],
}


def load_json(path: Path) -> Dict:
    with open(path, "r", encoding="utf-8") as f:
        return json.load(f)


def normalize_skill(skill: str) -> str:
    s = str(skill).strip().lower()
    return ROLE_ALIASES.get(s, skill.strip())


def normalize_skill_list(skills: List[str]) -> List[str]:
    result = []
    seen = set()
    for skill in skills:
        normalized = normalize_skill(skill)
        key = normalized.lower()
        if key and key not in seen:
            seen.add(key)
            result.append(normalized)
    return result


def safe_float_div(a: float, b: float) -> float:
    return a / b if b else 0.0


def compute_skill_overlap(cv_skills: List[str], role_skills: List[str]) -> Tuple[List[str], List[str], float]:
    cv_norm = normalize_skill_list(cv_skills)
    role_norm = normalize_skill_list(role_skills)

    cv_set = {s.lower(): s for s in cv_norm}
    role_set = {s.lower(): s for s in role_norm}

    matched_keys = sorted(set(cv_set.keys()) & set(role_set.keys()))
    missing_keys = sorted(set(role_set.keys()) - set(cv_set.keys()))

    matched = [role_set[k] for k in matched_keys]
    missing = [role_set[k] for k in missing_keys]

    overlap_score = safe_float_div(len(matched), max(len(role_norm), 1))
    return matched, missing, overlap_score


def compute_keyword_match(cv_info: Dict, role_name: str, role_keywords: List[str]) -> float:
    score = 0.0

    text_parts = []
    text_parts.extend(cv_info.get("skills", []))
    text_parts.extend(cv_info.get("projects", []))
    text_parts.extend(cv_info.get("education_signals", []))
    text_parts.append(cv_info.get("target_role", ""))

    joined = " ".join([str(x).lower() for x in text_parts if x])

    keyword_hits = 0
    for kw in role_keywords:
        if kw.lower() in joined:
            keyword_hits += 1

    score += safe_float_div(keyword_hits, max(len(role_keywords), 1))

    target_role = str(cv_info.get("target_role", "")).strip().lower()
    if target_role and target_role != "unknown" and role_name.lower() == target_role:
        score += 0.5

    return min(score, 1.0)


def compute_experience_match(cv_experience_years: str, role_name: str, role_profile: Dict) -> float:
    value = str(cv_experience_years).strip().lower()

    if value == "unknown":
        return 0.4

    try:
        years = int(value)
    except ValueError:
        return 0.4

    common_patterns = " ".join(role_profile.get("common_experience_patterns", [])).lower()

    if role_name in ["Data Analyst", "Data Scientist"] and years <= 2:
        return 1.0
    if role_name == "Data Engineer" and years <= 1:
        return 0.6
    if role_name == "AI Engineer" and years <= 1:
        return 0.6
    if role_name == "AI Researcher" and years <= 1:
        return 0.6
    if role_name == "Data Labeling" and years <= 1:
        return 1.0

    if "fresher" in common_patterns or "không yêu cầu" in common_patterns:
        return 1.0

    if years <= 3:
        return 0.8
    return 0.7


def score_role(cv_info: Dict, role_name: str, role_profile: Dict) -> Dict:
    cv_skills = cv_info.get("skills", [])
    role_skills = role_profile.get("common_skills", [])

    matched_skills, missing_skills, skill_overlap_score = compute_skill_overlap(cv_skills, role_skills)

    role_keywords = role_profile.get("common_keywords", [])
    if not role_keywords:
        role_keywords = ROLE_KEYWORD_HINTS.get(role_name, [])

    keyword_match_score = compute_keyword_match(cv_info, role_name, role_keywords)
    experience_match_score = compute_experience_match(
        cv_info.get("experience_years", "Unknown"),
        role_name,
        role_profile,
    )

    target_role_match_score = 0.0
    target_role = str(cv_info.get("target_role", "")).strip().lower()
    if target_role and target_role != "unknown" and role_name.lower() == target_role:
        target_role_match_score = 1.0

    final_score = (
        0.5 * skill_overlap_score
        + 0.2 * keyword_match_score
        + 0.2 * experience_match_score
        + 0.1 * target_role_match_score
    )

    return {
        "role_name": role_name,
        "score": round(final_score, 4),
        "skill_overlap_score": round(skill_overlap_score, 4),
        "keyword_match_score": round(keyword_match_score, 4),
        "experience_match_score": round(experience_match_score, 4),
        "target_role_match_score": round(target_role_match_score, 4),
        "matched_skills": matched_skills,
        "missing_skills": missing_skills,
        "recommended_next_skills": role_profile.get("recommended_next_skills", []),
        "common_skills": role_profile.get("common_skills", []),
    }


def build_development_plan(best_role_result: Dict, cv_info: Dict) -> List[str]:
    plan = []

    missing_skills = best_role_result.get("missing_skills", [])
    recommended = best_role_result.get("recommended_next_skills", [])

    for skill in missing_skills[:3]:
        plan.append(f"Học hoặc củng cố {skill}")

    for skill in recommended:
        if len(plan) >= 5:
            break
        if all(skill.lower() not in p.lower() for p in plan):
            plan.append(f"Phát triển thêm {skill}")

    projects = cv_info.get("projects", [])
    if not projects:
        plan.append("Bổ sung ít nhất 1 project thực tế vào CV")

    return plan[:5]


def analyze_cv_against_roles(cv_info: Dict, role_profiles: Dict) -> Dict:
    role_results = []

    for role_name, role_profile in role_profiles.items():
        result = score_role(cv_info, role_name, role_profile)
        role_results.append(result)

    role_results = sorted(role_results, key=lambda x: x["score"], reverse=True)

    best_fit_roles = [r["role_name"] for r in role_results[:3]]
    best_role_result = role_results[0] if role_results else {}

    strengths = best_role_result.get("matched_skills", [])
    missing_skills = best_role_result.get("missing_skills", [])
    development_plan = build_development_plan(best_role_result, cv_info)

    domain_fit = "high"
    if best_role_result:
        top_score = best_role_result["score"]
        if top_score < 0.35:
            domain_fit = "low"
        elif top_score < 0.6:
            domain_fit = "medium"

    return {
        "cv_file_name": cv_info.get("file_name", ""),
        "target_role_from_cv": cv_info.get("target_role", "Unknown"),
        "domain_fit": domain_fit,
        "best_fit_roles": best_fit_roles,
        "top_role_result": best_role_result,
        "strengths": strengths,
        "missing_skills": missing_skills,
        "development_plan": development_plan,
        "role_scores": role_results,
    }


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--cv_json", required=True, help="Path to extracted CV JSON")
    parser.add_argument("--role_profiles", default=str(ROLE_PROFILE_PATH), help="Path to role_profiles.json")
    parser.add_argument("--output_path", default=str(DEFAULT_OUTPUT_PATH), help="Path to save result JSON")
    args = parser.parse_args()

    cv_json_path = Path(args.cv_json)
    role_profile_path = Path(args.role_profiles)
    output_path = Path(args.output_path)

    cv_info = load_json(cv_json_path)
    role_profiles = load_json(role_profile_path)

    result = analyze_cv_against_roles(cv_info, role_profiles)

    print(json.dumps(result, ensure_ascii=False, indent=2))

    output_path.parent.mkdir(parents=True, exist_ok=True)
    with open(output_path, "w", encoding="utf-8") as f:
        json.dump(result, f, ensure_ascii=False, indent=2)

    print(f"\nSaved gap analysis result to: {output_path}")


if __name__ == "__main__":
    main()